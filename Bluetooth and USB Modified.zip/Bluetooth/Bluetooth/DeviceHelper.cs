﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Devices.Enumeration;
using Windows.UI.Xaml.Media.Imaging;

namespace Bluetooth
{
    public class DeviceSelectorInfo
    {
        public string DisplayName { get; set; }
        public DeviceClass DeviceClassSelector { get; set; } = DeviceClass.All;
        public DeviceInformationKind Kind { get; set; } = DeviceInformationKind.Unknown;
        public string Selector { get; set; }
    }

    public static class DeviceSelectorChoices
    {

        public static List<DeviceSelectorInfo> CommonDeviceSelectors => new List<DeviceSelectorInfo>()
        {
            // Pre-canned device class selectors
            new DeviceSelectorInfo() { DisplayName = "USB", DeviceClassSelector = DeviceClass.PortableStorageDevice, Selector = null },
        };


        public static DeviceSelectorInfo Bluetooth =>
            new DeviceSelectorInfo() { DisplayName = "Bluetooth", Selector = "System.Devices.Aep.ProtocolId:=\"{e0cbf06c-cd8b-4647-bb8a-263b43f0f974}\"", Kind = DeviceInformationKind.AssociationEndpoint };



        public static List<DeviceSelectorInfo> DeviceWatcherSelectors
        {
            get
            {
                // Add all selectors that can be used with the DeviceWatcher
                List<DeviceSelectorInfo> selectors = new List<DeviceSelectorInfo>(CommonDeviceSelectors);
                selectors.Add(Bluetooth);
                return selectors;
            }
        }



        /// <summary>
        /// Selectors for use in the pairing scenarios
        /// </summary>
        public static List<DeviceSelectorInfo> PairingSelectors
        {
            get
            {

                List<DeviceSelectorInfo> selectors = new List<DeviceSelectorInfo>();
                selectors.Add(Bluetooth);
                return selectors;
            }
        }
    }

    public class DeviceInformationDisplay : INotifyPropertyChanged
    {
        public DeviceInformationDisplay(DeviceInformation deviceInfoIn)
        {
            DeviceInformation = deviceInfoIn;
            UpdateGlyphBitmapImage();
        }

        public DeviceInformationKind Kind => DeviceInformation.Kind;


        public string Id => DeviceInformation.Id;
        public string VID => DeviceInformation.Id.Substring(12, 4);
        public string PID => DeviceInformation.Id.Substring(21, 4);
        //string VID;
        //string PID;


        public string Name => DeviceInformation.Name;
        public BitmapImage GlyphBitmapImage { get; private set; }
        public bool CanPair => DeviceInformation.Pairing.CanPair;
        public bool IsPaired => DeviceInformation.Pairing.IsPaired;
        public IReadOnlyDictionary<string, object> Properties => DeviceInformation.Properties;
       
        public DeviceInformation DeviceInformation { get; private set; }

        public void Update(DeviceInformationUpdate deviceInfoUpdate)
        {
            DeviceInformation.Update(deviceInfoUpdate);
          
 
           OnPropertyChanged("Kind");
            OnPropertyChanged("Id");
            OnPropertyChanged("Name");
            OnPropertyChanged("DeviceInformation");
            OnPropertyChanged("CanPair");
            OnPropertyChanged("IsPaired");
            OnPropertyChanged("GetPropertyForDisplay");
            OnPropertyChanged("Properties");
           


            UpdateGlyphBitmapImage();
        }

        public string GetPropertyForDisplay(string key) => Properties[key]?.ToString();

        private async void UpdateGlyphBitmapImage()
        {
            DeviceThumbnail deviceThumbnail = await DeviceInformation.GetGlyphThumbnailAsync();
            BitmapImage glyphBitmapImage = new BitmapImage();
            await glyphBitmapImage.SetSourceAsync(deviceThumbnail);
            GlyphBitmapImage = glyphBitmapImage;
            OnPropertyChanged("GlyphBitmapImage");
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
